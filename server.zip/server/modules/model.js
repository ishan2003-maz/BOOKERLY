const mongoose = require('mongoose');
const { type } = require('os');
const {start} = require('repl');

const registerSchema = new mongoose.Schema({
    name: {
        type: String,
    },
    email: {
        type: String,
    },
    phone_number: {
        type: Number,
    },
    password: {
        type: String,
    },
})

module.exports = mongoose.model('Users', registerSchema);