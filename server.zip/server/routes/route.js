const express = require('express')
const router = express.Router();

const {registerUser} = require('../controler/user');
const {loginUser, allData} = require('../controler/login');
const { registerUser2 } = require('../controler/register');
// const { allData } = require('../../../../../Downloads/server/controller/login');

router.route('/registeruser2').post(registerUser2);
router.route('/registeruser').post(registerUser);
router.route('/login').get(loginUser);
router.route('/all').get(allData);



module.exports = router;
