const model = require('../modules/model');
const registerUser2 = async (req, res) => {
    const data = {
        username: req.query.username,
        email: req.query.email,
        phone_number: req.query.number,
        password: req.query.password,
        c_pass: req.query.c_pass
    }
    function checkEmail(email) {
        const regex = /^(?=[^@]*\d)[^\s@]+@[^\s@]+\.[^\s@]+$/;
        return regex.test(email);
    }
    if (data.username.length === 0 || data.email.length === 0 || data.phone_number.length === 0 || data.password.length === 0 || data.c_pass.length === 0) {
        res.status(400).json("Please fill up all the inputs properly");
    } else if (!checkEmail(data.email)) {
        res.status(401).json("Invalid email format");
    } else if (data.phone_number.length < 10) {
        res.status(402).json("Invalid phone number format");
    } else if (data.c_pass !== data.password) {
        res.status(410).json("Password and confirm password are not the same");
    } else {
        res.status(200).json({ message: "User Register Successfully", data: data });
    }
}
module.exports = { registerUser2 }